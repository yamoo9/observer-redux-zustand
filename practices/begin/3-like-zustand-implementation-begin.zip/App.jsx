import { useState } from 'react';

function App() {
  return (
    <>
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [state, setState] = useState({ count: 0 });
  const updateCount = () => {
    setState({
      count: state.count + 1,
    });
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [state, setState] = useState({ count: 0 });
  const updateCount = () => {
    setState({
      count: state.count + 1,
    });
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
    </div>
  );
}

export default App;
