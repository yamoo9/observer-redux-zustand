function Headline() {
  return <h2 className="headline">Zustand처럼 생각하기</h2>;
}

export default Headline;
