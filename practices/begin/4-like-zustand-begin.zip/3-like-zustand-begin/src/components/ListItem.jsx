import { useContext } from 'react';
import { AppContext } from '../App';

function ListItem({ item }) {
  const { list, count } = useContext(AppContext);

  const handleDeleteItem = (id) => () => {
    list.deleteItem(id);
    count.decrementCount(1);
  };

  return (
    <li data-id={item.id}>
      {item.title}
      <button
        type="button"
        className="button"
        onClick={handleDeleteItem(item.id)}
      >
        삭제
      </button>
    </li>
  );
}

export default ListItem;
