import { useContext } from 'react';
import { AppContext } from '../App';

function Input() {
  const { itemRef } = useContext(AppContext);

  return (
    <div>
      <label htmlFor="newItem" className="sr-only">
        수행 항목
      </label>
      <input
        ref={itemRef}
        type="text"
        name="newItem"
        id="newItem"
        placeholder="예) Zustand 구현하기"
      />
    </div>
  );
}

export default Input;
