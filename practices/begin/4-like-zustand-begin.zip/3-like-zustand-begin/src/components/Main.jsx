import Wrapper from './Wrapper';

function Main() {
  return (
    <main>
      <Wrapper />
    </main>
  );
}

export default Main;
