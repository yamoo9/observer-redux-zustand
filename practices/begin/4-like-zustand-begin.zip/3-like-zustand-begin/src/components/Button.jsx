function Button() {
  return (
    <button type="submit" className="button">
      추가
    </button>
  );
}

export default Button;
