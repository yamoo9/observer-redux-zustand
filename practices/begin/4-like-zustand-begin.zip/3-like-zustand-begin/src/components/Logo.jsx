function Logo() {
  return (
    <img
      className="logo"
      src="https://tailwindui.com/img/logos/mark.svg?color=cyan&shade=400"
      alt="로고"
    />
  );
}

export default Logo;
