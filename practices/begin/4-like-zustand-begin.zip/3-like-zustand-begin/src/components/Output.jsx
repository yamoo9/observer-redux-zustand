import { useContext } from 'react';
import { AppContext } from '../App';

function Output() {
  const { count } = useContext(AppContext);

  return <output className="output">{count.data}</output>;
}

export default Output;
