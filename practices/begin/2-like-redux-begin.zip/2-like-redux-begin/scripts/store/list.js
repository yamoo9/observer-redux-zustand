// listReducer와 actionTypes, actionCreators를 작성합니다.
