// countReducer, listReducer를 combineReducers로 병합합니다.
// createStore 함수를 사용해 store를 생성합니다.
