import { create } from '../lib/like-zustand';

export const useCountStore = create((set) => ({
  count: 0,

  incrementCount: (by) =>
    set((state) => ({
      ...state,
      count: state.count + by,
    })),
  decrementCount: (by) =>
    set((state) => ({
      ...state,
      count: state.count - by,
    })),
}));
