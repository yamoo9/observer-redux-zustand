import { create } from '../lib/like-zustand';

export const useListStore = create((set) => ({
  list: [],

  addItem: (newItem) => {
    set((state) => ({
      ...state,
      list: [...state.list, { id: crypto.randomUUID(), title: newItem }],
    }));
  },
  deleteItem: (deleteId) => {
    set((state) => ({
      ...state,
      list: state.list.filter((item) => item.id !== deleteId),
    }));
  },
}));
