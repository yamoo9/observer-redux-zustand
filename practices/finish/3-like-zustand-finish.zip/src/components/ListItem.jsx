import { useCountStore } from '../store/count';
import { useListStore } from '../store/list';

function ListItem({ item }) {
  const deleteItem = useListStore((state) => state.deleteItem);
  const decrementCount = useCountStore((state) => state.decrementCount);

  const handleDeleteItem = (id) => () => {
    deleteItem(id);
    decrementCount(1);
  };

  return (
    <li data-id={item.id}>
      {item.title}
      <button
        type="button"
        className="button"
        onClick={handleDeleteItem(item.id)}
      >
        삭제
      </button>
    </li>
  );
}

export default ListItem;
