import { useListStore } from '../store/list';
import ListItem from './ListItem';

function List() {
  const list = useListStore((state) => state.list);

  const length = list.length ?? 0;

  return (
    <ul className={`list ${length === 0 ? 'empty' : ''}`}>
      {length > 0 ? (
        list?.map((item) => <ListItem key={item.id} item={item} />)
      ) : (
        <li>표시할 항목이 없습니다.</li>
      )}
    </ul>
  );
}

export default List;
