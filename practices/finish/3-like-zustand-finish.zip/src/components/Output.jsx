import { useCountStore } from '../store/count';

function Output() {
  const count = useCountStore((state) => state.count);

  return <output className="output">{count}</output>;
}

export default Output;
