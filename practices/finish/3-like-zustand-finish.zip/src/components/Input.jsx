import { forwardRef, useImperativeHandle, useRef } from 'react';

const Input = forwardRef(function Input(props, ref) {
  const inputRef = useRef(null);

  useImperativeHandle(ref, () => {
    const { current: input } = inputRef;

    return {
      getInputValue() {
        return input.value;
      },
      selectInputContent() {
        input.select();
      },
      resetInput() {
        input.value = '';
      },
    };
  });

  return (
    <div>
      <label htmlFor="newItem" className="sr-only">
        수행 항목
      </label>
      <input
        ref={inputRef}
        type="text"
        name="newItem"
        id="newItem"
        placeholder="예) Zustand 구현하기"
      />
    </div>
  );
});

export default Input;
