import Button from './Button';
import Input from './Input';
import { useListStore } from '../store/list';
import { useCountStore } from '../store/count';
import { useRef } from 'react';

function Form() {
  const inputRef = useRef(null);
  const addItem = useListStore((state) => state.addItem);
  const incrementCount = useCountStore((state) => state.incrementCount);

  const handleAddItem = (e) => {
    e.preventDefault();

    const { current: input } = inputRef;

    const newItem = input.getInputValue();

    if (!newItem.trim()) {
      alert('추가할 항목을 입력해야 합니다.');
      return input.selectInputContent();
    }

    addItem(newItem);
    incrementCount(1);

    input.resetInput();
  };

  return (
    <form className="form" onSubmit={handleAddItem}>
      <Input ref={inputRef} />
      <Button />
    </form>
  );
}

export default Form;
