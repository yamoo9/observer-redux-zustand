import { decrementCount, incrementCount } from './store/counter.js';
import { addItem, removeItem } from './store/list.js';
import { store } from './store/store.js';

/* DOM Elements ------------------------------------------------------------- */

const form = document.querySelector('.form');
const output = document.querySelector('.output');
const listElement = document.querySelector('.list');

/* Functions ---------------------------------------------------------------- */

function renderList() {
  const { list } = store.getState();

  cleanUpList();

  const markup = list
    .map(
      (item) => `
      <li data-id="${item.id}">
        ${item.title}
        <button type="button" class="button">삭제</button>
      </li>
    `
    )
    .join('');

  listElement.innerHTML = markup;
}

function cleanUpList() {
  listElement.innerHTML = '';
}

function cleanUpForm() {
  form.newItem.value = '';
}

function renderCount() {
  const { count } = store.getState();
  output.textContent = String(count);
}

/* Subscription ------------------------------------------------------------- */

store.subscribe(renderCount);
store.subscribe(renderList);

/* Notification ------------------------------------------------------------- */

function handleAddItem(e) {
  e.preventDefault();

  const newItem = e.target.newItem;

  if (!newItem.value.trim()) {
    alert('추가할 항목을 입력해야 합니다.');
    return newItem.select();
  }

  store.dispatch(
    addItem({
      id: crypto.randomUUID(),
      title: e.target.newItem.value,
    })
  );

  store.dispatch(incrementCount(1));

  cleanUpForm();
}

form?.addEventListener('submit', handleAddItem);

/* App ---------------------------------------------------------------------- */

function render() {
  renderList();
  renderCount();
}

function app() {
  render();

  listElement.addEventListener('click', (e) => {
    if (e.target.matches('button')) {
      const id = e.target.parentElement.dataset.id;
      store.dispatch(removeItem(id));
      store.dispatch(decrementCount(1));
    }
  });
}

app();
