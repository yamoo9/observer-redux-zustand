const initialCount = 0;

export function reducer(state = initialCount, action) {
  switch (action.type) {
    case INCREMENT_COUNT:
      return state + action.payload;
    case DECREMENT_COUNT:
      return state - action.payload;
    case RESET_COUNT:
      return initialCount;
    default:
      return state;
  }
}

const INCREMENT_COUNT = 'INCREMENT_COUNT';
const DECREMENT_COUNT = 'DECREMENT_COUNT';
const RESET_COUNT = 'RESET_COUNT';

export const incrementCount = (by) => ({
  type: INCREMENT_COUNT,
  payload: by,
});

export const decrementCount = (by) => ({
  type: DECREMENT_COUNT,
  payload: by,
});

export const resetCount = () => ({
  type: RESET_COUNT,
});
