const initialList = [];

export function reducer(state = initialList, action) {
  switch (action.type) {
    case ADD_ITEM:
      return [...state, action.payload];
    case EDIT_ITEM:
      return state.map((item) => {
        if (item.id === action.payload.id) {
          return { ...item, ...action.payload };
        } else {
          return item;
        }
      });
    case REMOVE_ITEM:
      return state.filter((item) => item.id !== action.payload);
    case RESET_LIST:
      return initialList;
    default:
      return state;
  }
}

const ADD_ITEM = 'ADD_ITEM';
const EDIT_ITEM = 'EDIT_ITEM';
const REMOVE_ITEM = 'REMOVE_ITEM';
const RESET_LIST = 'RESET_LIST';

export const addItem = (newItem) => ({
  type: ADD_ITEM,
  payload: newItem,
});
export const editItem = (willEditItem) => ({
  type: EDIT_ITEM,
  payload: willEditItem,
});
export const removeItem = (removeId) => ({
  type: REMOVE_ITEM,
  payload: removeId,
});

export const resetList = () => ({
  type: RESET_LIST,
});
