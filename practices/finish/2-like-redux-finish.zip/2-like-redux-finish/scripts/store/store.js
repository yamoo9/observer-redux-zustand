import { createStore, combineReducers } from '../lib/likeRedux.js';
import { reducer as countReducer } from './counter.js';
import { reducer as listReducer } from './list.js';

const rootReducer = combineReducers({
  count: countReducer,
  list: listReducer,
});

const listData = [
  {
    id: crypto.randomUUID(),
    title: '리덕스처럼 생각하기 (Thinking in Redux)',
  },
];

export const store = createStore(rootReducer, {
  count: listData.length,
  list: listData,
});
