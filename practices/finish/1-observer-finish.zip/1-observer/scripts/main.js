import Observable from './lib/Observable.js';

/* Functions ---------------------------------------------------------------- */

const getListItems = () => listElement?.children.length;

const addListItem = () => {
  const index = getListItems();

  const listItem = document.createElement('li');
  listItem.textContent = `아이템 ${index + 1}`;
  listElement?.append(listItem);
};

const renderOutput = () => {
  output.textContent = getListItems();
};

/* Subscription ------------------------------------------------------------- */

Observable.subscribe(addListItem);
Observable.subscribe(renderOutput);

/* Notification ------------------------------------------------------------- */

const listElement = document.querySelector('.list');
const addButton = document.querySelector('.button');
const output = document.querySelector('.output');

addButton?.addEventListener('click', () => {
  Observable.notify();
});
