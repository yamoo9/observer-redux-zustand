import { useEffect, useState } from 'react';

/* Library Code ------------------------------------------------------------- */

function createStore(initialState) {
  let state = initialState;
  const listeners = new Set();

  const getState = () => state;

  const setState = (nextState) => {
    state = typeof nextState === 'function' ? nextState(state) : nextState;
    listeners.forEach((listener) => listener());
  };

  const subscribe = (listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };

  return { getState, setState, subscribe };
}

function useStore(store, selector = (x) => x) {
  const [state, setState] = useState(selector(store.getState()));

  useEffect(() => {
    const callback = () => {
      setState(selector(store.getState()));
    };
    const unsubcribe = store.subscribe(callback);
    return unsubcribe;
  }, [store, selector]);

  return [state, store.setState];
}

/* -------------------------------------------------------------------------- */

const store = createStore({
  count1: 0,
  count2: 0,
});

/* Application Code --------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [count1, setState] = useStore(store, (state) => state.count1);

  const updateCount = () => {
    setState((state) => ({ ...state, count1: count1 + 1 }));
  };

  return (
    <div className="counter">
      <span>{count1}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [count2, setState] = useStore(store, (state) => state.count2);

  const updateCount = () => {
    setState((state) => ({ ...state, count2: count2 + 1 }));
  };

  return (
    <div className="counter">
      <span>{count2}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
      <Counter2 />
    </div>
  );
}

export default App;
