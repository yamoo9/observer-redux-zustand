import { useState } from 'react';

let moduleState = {
  count: 0,
};

/* -------------------------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [state, setState] = useState(moduleState);
  const updateCount = () => {
    moduleState = {
      count: moduleState.count + 1,
    };
    setState(moduleState);
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [state, setState] = useState({ count: 0 });
  const updateCount = () => {
    moduleState = {
      count: moduleState.count + 1,
    };
    setState(moduleState);
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
    </div>
  );
}

export default App;
