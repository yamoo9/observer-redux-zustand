import { useEffect, useState } from 'react';

function createStore(initialState) {
  let state = initialState;
  const listeners = new Set();

  const getState = () => state;

  const setState = (nextState) => {
    state = nextState;
    listeners.forEach((listener) => listener());
  };

  const subscribe = (listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };

  return { getState, setState, subscribe };
}

function useStore(store) {
  const [state, setState] = useState(store.getState());

  useEffect(() => {
    const callback = () => {
      setState(store.getState());
    };
    const unsubcribe = store.subscribe(callback);
    return unsubcribe;
  }, [store]);

  return [state, store.setState];
}

/* -------------------------------------------------------------------------- */

const store = createStore({
  count: 0,
});

/* -------------------------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [state, setState] = useStore(store);

  const updateCount = () => {
    const nextState = { count: store.getState().count + 1 };
    setState(nextState);
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [state, setState] = useStore(store);

  const updateCount = () => {
    const nextState = { count: store.getState().count + 1 };
    setState(nextState);
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
    </div>
  );
}

export default App;
