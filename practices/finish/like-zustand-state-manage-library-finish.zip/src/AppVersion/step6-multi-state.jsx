import { useEffect, useState } from 'react';

/* Library Code ------------------------------------------------------------- */

function createStore(initialState) {
  let state = initialState;
  const listeners = new Set();

  const getState = () => state;

  const setState = (nextState) => {
    state = typeof nextState === 'function' ? nextState(state) : nextState;
    listeners.forEach((listener) => listener());
  };

  const subscribe = (listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };

  return { getState, setState, subscribe };
}

function useStore(store) {
  const [state, setState] = useState(store.getState());

  useEffect(() => {
    const callback = () => {
      setState(store.getState());
    };
    const unsubcribe = store.subscribe(callback);
    return unsubcribe;
  }, [store]);

  return [state, store.setState];
}

/* -------------------------------------------------------------------------- */

const store = createStore({
  count1: 0,
  count2: 0,
});

/* Application Code --------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [state, setState] = useStore(store);

  const updateCount = () => {
    setState((state) => ({ ...state, count1: state.count1 + 1 }));
  };

  return (
    <div className="counter">
      <span>{state.count1}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [state, setState] = useStore(store);

  const updateCount = () => {
    setState((state) => ({ ...state, count2: state.count2 + 1 }));
  };

  return (
    <div className="counter">
      <span>{state.count2}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
      <Counter2 />
    </div>
  );
}

export default App;
