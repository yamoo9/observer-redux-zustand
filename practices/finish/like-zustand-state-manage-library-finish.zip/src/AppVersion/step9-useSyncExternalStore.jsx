import { useSyncExternalStore } from 'react';

/* Library Code ------------------------------------------------------------- */

function createStore(createState) {
  const listeners = new Set();

  const getState = () => state;

  const setState = (nextState) => {
    state = typeof nextState === 'function' ? nextState(state) : nextState;
    listeners.forEach((listener) => listener());
  };

  let state = createState(setState, getState);

  const subscribe = (listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };

  return { getState, setState, subscribe };
}

function useStore(store, selector = (x) => x) {
  return useSyncExternalStore(store.subscribe, () =>
    selector(store.getState())
  );
}

/* -------------------------------------------------------------------------- */

const store = createStore((set) => ({
  count1: 0,
  count2: 0,
  updateCount1: () => {
    set((state) => ({ ...state, count1: state.count1 + 1 }));
  },
  updateCount2: () => {
    set((state) => ({ ...state, count2: state.count2 + 1 }));
  },
}));

/* Application Code --------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const count1 = useStore(store, (state) => state.count1);
  const updateCount1 = useStore(store, (state) => state.updateCount1);

  return (
    <div className="counter">
      <span>{count1}</span>
      <button type="button" onClick={updateCount1}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const count2 = useStore(store, (state) => state.count2);
  const updateCount2 = useStore(store, (state) => state.updateCount2);

  return (
    <div className="counter">
      <span>{count2}</span>
      <button type="button" onClick={updateCount2}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
      <Counter2 />
    </div>
  );
}

export default App;
