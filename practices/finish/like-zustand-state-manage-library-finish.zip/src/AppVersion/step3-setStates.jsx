import { useEffect, useState } from 'react';

let moduleState = {
  count: 0,
};

const setStates = new Set();

/* -------------------------------------------------------------------------- */

function App() {
  return (
    <>
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const [state, setState] = useState(moduleState);

  useEffect(() => {
    setStates.add(setState);
    return () => {
      setStates.delete(setState);
    };
  }, []);

  const updateCount = () => {
    moduleState = {
      count: moduleState.count + 1,
    };
    setStates.forEach((set) => set(moduleState));
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const [state, setState] = useState(moduleState);

  useEffect(() => {
    setStates.add(setState);
    return () => {
      setStates.delete(setState);
    };
  }, []);

  const updateCount = () => {
    moduleState = {
      count: moduleState.count + 1,
    };
    setStates.forEach((set) => set(moduleState));
  };

  return (
    <div className="counter">
      <span>{state.count}</span>
      <button type="button" onClick={updateCount}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
    </div>
  );
}

export default App;
