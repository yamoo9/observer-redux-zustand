import { create } from '../lib/like-zustand';

export const useCountStore = create((set) => ({
  count1: 0,
  count2: 0,
  updateCount1: () => {
    set((state) => ({ ...state, count1: state.count1 + 1 }));
  },
  updateCount2: () => {
    set((state) => ({ ...state, count2: state.count2 + 1 }));
  },
}));
