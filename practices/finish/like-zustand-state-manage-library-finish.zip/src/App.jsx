import { useCountStore } from './store/count';

function App() {
  return (
    <>
      <Counter1 />
      <Counter1 />
      <Parent />
    </>
  );
}

/* -------------------------------------------------------------------------- */

function Counter1() {
  const count1 = useCountStore((state) => state.count1);
  const updateCount1 = useCountStore((state) => state.updateCount1);

  return (
    <div className="counter">
      <span>{count1}</span>
      <button type="button" onClick={updateCount1}>
        +1
      </button>
    </div>
  );
}

function Counter2() {
  const count2 = useCountStore((state) => state.count2);
  const updateCount2 = useCountStore((state) => state.updateCount2);

  return (
    <div className="counter">
      <span>{count2}</span>
      <button type="button" onClick={updateCount2}>
        +1
      </button>
    </div>
  );
}

function Parent() {
  return (
    <div className="parent">
      <Counter2 />
      <Counter2 />
    </div>
  );
}

export default App;
